#include "types.h"
#include "user.h"
int main(int argc,char* argv[]){
	int r=rrand();
	printf(1,"random number is:%d\n",r);
	exit();
}
