#include "types.h"


#define RAND_MAX (1<<31)

void srand(unsigned seed);
int rand(void);

